package com.example.mealplanner
import android.content.*
import android.database.sqlite.*

data class Meal(val id:Long,val name:String,val category:String,val notes:String,var lastSelected:Long)

class MealDbHelper(c:Context):SQLiteOpenHelper(c,"meals.db",null,2){
 override fun onCreate(db:SQLiteDatabase){db.execSQL("CREATE TABLE meals(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,category TEXT NOT NULL,notes TEXT NOT NULL DEFAULT '',last_selected INTEGER NOT NULL DEFAULT 0)")}
 override fun onUpgrade(db:SQLiteDatabase,old:Int,new:Int){if(old<2)db.execSQL("ALTER TABLE meals ADD COLUMN notes TEXT NOT NULL DEFAULT ''")}
 fun all():MutableList<Meal>{val r=mutableListOf<Meal>();readableDatabase.query("meals",null,null,null,null,null,null).use{c->while(c.moveToNext())r.add(Meal(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getLong(4)))};return r}
 fun save(id:Long?,name:String,cat:String,notes:String){val v=ContentValues().apply{put("name",name);put("category",cat);put("notes",notes)};if(id==null)writableDatabase.insert("meals",null,v) else writableDatabase.update("meals",v,"id=?",arrayOf(id.toString()))}
 fun delete(id:Long){writableDatabase.delete("meals","id=?",arrayOf(id.toString()))}
 fun mark(ids:List<Long>){val v=ContentValues().apply{put("last_selected",System.currentTimeMillis())};writableDatabase.beginTransaction();try{ids.forEach{writableDatabase.update("meals",v,"id=?",arrayOf(it.toString()))};writableDatabase.setTransactionSuccessful()}finally{writableDatabase.endTransaction()}}
}