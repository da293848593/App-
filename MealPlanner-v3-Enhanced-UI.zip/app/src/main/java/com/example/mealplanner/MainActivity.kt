package com.example.mealplanner

import android.os.Bundle
import android.graphics.Color
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.max
import kotlin.random.Random

class MainActivity:AppCompatActivity(){
 private lateinit var db:MealDbHelper
 private val bg=Color.rgb(246,248,245); private val dark=Color.rgb(35,45,36); private val green=Color.rgb(79,111,82)
 override fun onCreate(b:Bundle?){super.onCreate(b);db=MealDbHelper(this);home()}
 private fun base():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(22,18,22,18);setBackgroundColor(bg)}
 private fun title(s:String):TextView=TextView(this).apply{text=s;textSize=30f;setTextColor(dark);setPadding(4,10,4,16);setTypeface(null,1)}
 private fun button(s:String,a:()->Unit)=Button(this).apply{text=s;setOnClickListener{a()};isAllCaps=false}
 private fun card(text:String):TextView=TextView(this).apply{text=text;textSize=17f;setTextColor(dark);setPadding(18,18,18,18);setBackgroundColor(Color.WHITE)}
 private fun home(){
  val l=base();l.addView(title("🍽  Meal Planner"))
  l.addView(card("${db.all().size} meals saved on this device"));l.addView(Space(this),LinearLayout.LayoutParams(1,12))
  l.addView(button("➕  Add a meal"){editor(null)});l.addView(button("📋  My meals"){meals()})
  l.addView(button("🎲  Pick 10 meals"){random()});l.addView(button("📅  Weekly planner"){week()});l.addView(button("🕘  Selection history"){history()})
  l.addView(Space(this),LinearLayout.LayoutParams(1,0,1f));l.addView(TextView(this).apply{text="Smart weighting favours meals you haven't had recently.";textSize=14f})
  setContentView(l)
 }
 private fun editor(old:Meal?){
  val l=base();l.addView(title(if(old==null)"Add a meal" else "Edit meal"))
  val n=EditText(this).apply{hint="Meal name";setText(old?.name?:"")};val c=EditText(this).apply{hint="Category";setText(old?.category?:"")};val notes=EditText(this).apply{hint="Notes / ingredients (optional)";setText(old?.notes?:"");minLines=3}
  l.addView(n);l.addView(c);l.addView(notes);l.addView(button("Save"){if(n.text.toString().trim().isEmpty())Toast.makeText(this,"Enter a meal name",Toast.LENGTH_SHORT).show()else{db.save(old?.id,n.text.toString().trim(),c.text.toString().trim().ifEmpty{"Other"},notes.text.toString());meals()}})
  l.addView(button("Cancel"){if(old==null)home()else meals()});setContentView(l)
 }
 private fun meals(filter:String="All"){
  val all=db.all();val cats=listOf("All")+all.map{it.category}.distinct().sorted();val l=base();l.addView(title("My meals"))
  val spinner=Spinner(this);spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,cats);spinner.setSelection(cats.indexOf(filter).coerceAtLeast(0));spinner.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){if(cats[pos]!=filter)meals(cats[pos])}};l.addView(spinner)
  val shown=if(filter=="All")all else all.filter{it.category==filter};if(shown.isEmpty())l.addView(card("No meals in this category."))
  shown.forEach{m->val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,8,0,8)};row.addView(card("${m.name}\n${m.category}${if(m.notes.isNotBlank())"\n"+m.notes else ""}"));val actions=LinearLayout(this);actions.addView(button("Edit"){editor(m)},LinearLayout.LayoutParams(0,-2,1f));actions.addView(button("Delete"){db.delete(m.id);meals(filter)},LinearLayout.LayoutParams(0,-2,1f));row.addView(actions);l.addView(row)}
  l.addView(button("➕ Add meal"){editor(null)});l.addView(button("Home"){home()});setContentView(l)
 }
 private fun random(){
  val all=db.all();if(all.size<10){Toast.makeText(this,"Add at least 10 meals first.",Toast.LENGTH_LONG).show();return}
  val chosen=sample(all,10);db.mark(chosen.map{it.id});val l=base();l.addView(title("🎲 Your 10 meals"));l.addView(card("Freshly selected — recent meals are weighted lower"))
  chosen.forEachIndexed{i,m->l.addView(card("${i+1}. ${m.name}\n${m.category}"))}
  l.addView(button("🔄 Pick again"){random()});l.addView(button("Home"){home()});setContentView(l)
 }
 private fun sample(src:List<Meal>,n:Int):List<Meal>{val p=src.toMutableList();val out=mutableListOf<Meal>();val now=System.currentTimeMillis();repeat(n){val w=p.map{m->if(m.lastSelected==0L)100.0 else max(5.0,minOf(100.0,10+(now-m.lastSelected).coerceAtLeast(0)/86400000.0*12))};var r=Random.nextDouble(w.sum());var x=0;for(i in w.indices){r-=w[i];if(r<=0){x=i;break}};out+=p.removeAt(x)};return out}
 private fun history(){
  val l=base();l.addView(title("🕘 Selection history"));db.all().sortedByDescending{it.lastSelected}.forEach{m->val s=if(m.lastSelected==0L)"Never selected" else "${((System.currentTimeMillis()-m.lastSelected)/86400000)} day(s) ago";l.addView(card("${m.name}\n${m.category} • $s"))};l.addView(button("Home"){home()});setContentView(l)
 }
 private fun week(){
  val l=base();l.addView(title("📅 Weekly planner"));l.addView(card("Plan your week from your saved meals. Tap a day to choose a meal."))
  val days=arrayOf("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday");days.forEach{day->l.addView(button(day+"  —  Choose meal"){chooseDay(day)})};l.addView(button("Home"){home()});setContentView(l)
 }
 private fun chooseDay(day:String){
  val all=db.all();if(all.isEmpty()){Toast.makeText(this,"Add some meals first.",Toast.LENGTH_SHORT).show();return}
  val names=all.map{it.name}.toTypedArray();AlertDialog.Builder(this).setTitle("$day meal").setItems(names){_,which->Toast.makeText(this,"$day: ${names[which]}",Toast.LENGTH_SHORT).show()}.show()
 }
}